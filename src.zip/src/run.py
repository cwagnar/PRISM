import numpy as np
import laspy
import argparse
from pathlib import Path
from sklearn.cluster import DBSCAN
import pandas as pd
import matplotlib.pyplot as plt
from pyproj import CRS
import json
from itertools import permutations

# =========================================================
# IO
# =========================================================
def load_laz(file_path):
    las = laspy.read(file_path)
    points = np.vstack((las.x, las.y, las.z)).T
    intensity = las.intensity.astype(np.float32)
    return las, points, intensity

def load_ground_truth(csv_path):
    """
    CSV format:

    First line:
        EPSG:26910

    Remaining rows:
        id,easting,northing,height
    """

    # -------------------------------------------------
    # READ FIRST LINE (EPSG)
    # -------------------------------------------------
    with open(csv_path, "r") as f:
        first_line = f.readline().strip()

    epsg = None

    if first_line.lower().startswith("epsg"):

        # Example accepted formats:
        # EPSG:32618
        # EPSG:32618,,,
        # EPSG=32618
        # epsg 32618

        import re

        match = re.search(r"(\d+)", first_line)

        if match:
            epsg = int(match.group(1))
            print(f"Detected EPSG: {epsg}")
            skiprows = 1
        else:
            raise ValueError(f"Could not parse EPSG from line: {first_line}")

    else:
        skiprows = 0

    # -------------------------------------------------
    # LOAD COORDINATES
    # -------------------------------------------------
    df = pd.read_csv(
        csv_path,
        header=None,
        skiprows=skiprows,
        sep=r"\s+|\t+|,",
        engine="python"
    )

    print("CSV Columns:", df.columns.tolist())

    # -------------------------------------------------
    # Positional No-header CSV
    # -------------------------------------------------
    if all(isinstance(c, (int, np.integer)) for c in df.columns):

        print(
            "Detected numeric/no-header CSV → "
            "using ID column 0 and coordinate columns 1,2,3"
        )

        reflector_ids = df.iloc[:, 0].astype(str).to_numpy()

        coords = df.iloc[:, 1:4].values.astype(float)

        return reflector_ids, coords, epsg

    raise ValueError("Could not parse coordinate CSV")

# =========================================================
# CLUSTERING
# =========================================================
def cluster_points(points, eps=0.15, min_samples=10):
    return DBSCAN(eps=eps, min_samples=min_samples).fit(points).labels_

def cluster_diagnostics(cluster, cluster_int):
    """
    Summarizes geometry and intensity characteristics of
    one candidate reflector cluster.
    """

    centroid = compute_centroid(cluster)

    x_span = cluster[:, 0].max() - cluster[:, 0].min()
    y_span = cluster[:, 1].max() - cluster[:, 1].min()
    z_span = cluster[:, 2].max() - cluster[:, 2].min()

    xy_extent = max(x_span, y_span)

    radial_value = radial_coherence(cluster)

    range_m = np.linalg.norm(centroid[:2])

    return {
        "point_count": len(cluster),
        "range_m": range_m,
        "x_span_m": x_span,
        "y_span_m": y_span,
        "xy_extent_m": xy_extent,
        "z_extent_m": z_span,
        "radial_coherence": radial_value,
        "mean_intensity": np.mean(cluster_int),
        "max_intensity": np.max(cluster_int)
    }

# =========================================================
# BASIC FILTERS
# =========================================================

def leave_one_out_validation(src, dst):
    """
    Uses all but one matched reflector to estimate a transform,
    then evaluates error at the withheld reflector.
    """

    if len(src) < 4:
        raise ValueError(
            "At least four reflectors are required."
        )

    print("\n====================================")
    print("LEAVE-ONE-OUT VALIDATION")
    print("====================================")

    for held_out in range(len(src)):

        keep = np.ones(len(src), dtype=bool)
        keep[held_out] = False

        T = compute_umeyama(
            src[keep],
            dst[keep],
            with_scale=False
        )

        predicted = apply_transform(
            src[held_out:held_out + 1],
            T
        )[0]

        residual = predicted - dst[held_out]

        horizontal_error = np.linalg.norm(
            residual[:2]
        )

        vertical_error = abs(residual[2])

        error_3d = np.linalg.norm(residual)

        print(
            f"Withheld reflector {held_out + 1}: "
            f"H = {horizontal_error:.3f} m, "
            f"V = {vertical_error:.3f} m, "
            f"3D = {error_3d:.3f} m"
        )

def intensity_filter(points, intensity, percentile=99.7):
    thr = np.percentile(intensity, percentile)
    mask = intensity >= thr
    return points[mask], intensity[mask], mask

def compute_centroid(cluster):
    return np.mean(cluster, axis=0)

def reject_large_cluster(cluster, max_xy=1.0, max_z=0.5):
    xy = max(
        cluster[:, 0].max() - cluster[:, 0].min(),
        cluster[:, 1].max() - cluster[:, 1].min()
    )
    z = cluster[:, 2].max() - cluster[:, 2].min()

    return (xy > max_xy) or (z > max_z)

def intensity_purity(cluster_int):
    return np.mean(cluster_int > np.percentile(cluster_int, 90))

def radial_coherence(cluster):
    c = compute_centroid(cluster)
    d = np.linalg.norm(cluster[:, :2] - c[:2], axis=1)
    return np.std(d) / (np.mean(d) + 1e-6)

def save_reflector_configuration_table(
    survey_ids,
    ground_truth,
    T,
    path
):
    """
    Creates a reflector-configuration table relative to
    the transformed Pivox scanner origin.
    """

    # Scanner origin in transformed coordinates.
    scanner_utm = apply_transform(
        np.array([[0.0, 0.0, 0.0]]),
        T
    )[0]

    delta = ground_truth - scanner_utm

    horizontal_range = np.linalg.norm(
        delta[:, :2],
        axis=1
    )

    # Azimuth measured clockwise from north.
    azimuth_deg = (
        np.degrees(
            np.arctan2(
                delta[:, 0],
                delta[:, 1]
            )
        ) + 360.0
    ) % 360.0

    rows = []

    for i, reflector_id in enumerate(survey_ids):

        rows.append({
            "reflector_id": reflector_id,
            "easting_m": ground_truth[i, 0],
            "northing_m": ground_truth[i, 1],
            "height_m": ground_truth[i, 2],
            "horizontal_range_m": horizontal_range[i],
            "azimuth_deg": azimuth_deg[i],
            "relative_elevation_m": delta[i, 2]
        })

    pd.DataFrame(rows).to_csv(
        path,
        index=False
    )

    print(
        "Saved reflector configuration table:",
        path
    )

# =========================================================
# SCORING
# =========================================================
def reflector_score(cluster, intensity):
    centroid = compute_centroid(cluster)

    d = np.linalg.norm(cluster - centroid, axis=1)
    compactness = 1.0 / (np.std(d) + 1e-6)

    intensity_mean = np.mean(intensity)
    intensity_peak = np.mean(intensity > np.percentile(intensity, 90))

    range_m = np.linalg.norm(centroid[:2])
    range_score = np.exp(-range_m / 40.0)

    return (
        intensity_mean * 0.3 +
        intensity_peak * 0.3 +
        compactness * 0.2 +
        range_score * 0.2
    )


# =========================================================
# DETECTION
# =========================================================
def detect_reflectors(
    points,
    intensity,
    expected_targets,
    print_candidate_diagnostics=False
):

    pts, inten, mask = intensity_filter(points, intensity)

    # =========================================================
    # RANGE GATE (pre-clustering filter)
    # =========================================================
    r = np.linalg.norm(pts[:, :2], axis=1)
    mask_range = r <= 60.0

    pts = pts[mask_range]
    inten = inten[mask_range]

    labels = cluster_points(pts)

    clusters = []
    indices = []

    print(f"Clusters found: {len(set(labels))}")

    for label in set(labels):

        if label == -1:
            continue

        idx = np.where(labels == label)[0]

        cluster = pts[idx]
        cluster_int = inten[idx]

        centroid = compute_centroid(cluster)

        # Print diagnostics only when requested.
        if print_candidate_diagnostics:

            diagnostics = cluster_diagnostics(
                cluster,
                cluster_int
            )

            print(
                f"\nCandidate cluster {label}"
                f"\n  Points: {diagnostics['point_count']}"
                f"\n  Range: {diagnostics['range_m']:.2f} m"
                f"\n  XY extent: {diagnostics['xy_extent_m']:.3f} m"
                f"\n  Z extent: {diagnostics['z_extent_m']:.3f} m"
                f"\n  Radial coherence: "
                f"{diagnostics['radial_coherence']:.3f}"
                f"\n  Mean intensity: "
                f"{diagnostics['mean_intensity']:.1f}"
            )

        # Reject clusters beyond the processing range.
        range_m = np.linalg.norm(
            centroid[:2]
        )

        if range_m > 60.0:
            continue

        # Reject large or vertically extended clusters.
        if reject_large_cluster(cluster):
            continue

        # Reject clusters with poor radial consistency.
        if radial_coherence(cluster) > 0.6:
            continue

        if intensity_purity(cluster_int) < 0.6:
            continue

        clusters.append(
            (cluster, cluster_int)
        )

        indices.append(idx)

    # fallback
    if len(clusters) == 0:

        print("WARNING: fallback mode")

        labels_unique = [l for l in set(labels) if l != -1]

        clusters = [
            (pts[labels == l], inten[labels == l])
            for l in labels_unique
        ]

        indices = [
            np.where(labels == l)[0]
            for l in labels_unique
        ]

    # rank clusters
    order = np.argsort([
        reflector_score(c[0], c[1]) for c in clusters
    ])[::-1]

    clusters = [clusters[i] for i in order]
    indices = [indices[i] for i in order]

    selected = clusters[:expected_targets]
    selected_idx = indices[:expected_targets]

    centroids = np.array([
        compute_centroid(c[0]) for c in selected
    ])

    # =========================================================
    # BUILD BINARY CLASSIFICATION (GLOBAL POINT LABELS)
    # =========================================================

    # start with all zeros (background)
    classification = np.zeros(len(points), dtype=np.uint8)

    # NOTE: we are inside filtered space, so we must map back carefully
    # easiest robust approach: re-evaluate using original intensity filter mask

    # mark intensity-filtered + range-filtered points as candidates
    pts, inten, mask_intensity = intensity_filter(points, intensity)

    r = np.linalg.norm(pts[:, :2], axis=1)
    mask_range = r <= 60.0

    valid_mask = np.zeros(len(points), dtype=bool)
    valid_mask[np.where(mask_intensity)[0][mask_range]] = True

    # mark selected reflector points
    for idx in selected_idx:
        # idx refers to filtered pts indices
        global_idx = np.where(valid_mask)[0][idx]
        classification[global_idx] = 1

    return centroids, mask, selected_idx, classification


# =========================================================
# UMeyama TRANSFORM
# =========================================================
def compute_umeyama(src, dst, with_scale=False):

    src = np.asarray(src)
    dst = np.asarray(dst)

    mu_src = src.mean(axis=0)
    mu_dst = dst.mean(axis=0)

    src_c = src - mu_src
    dst_c = dst - mu_dst

    cov = src_c.T @ dst_c / len(src)

    U, S, Vt = np.linalg.svd(cov)

    R = Vt.T @ U.T

    if np.linalg.det(R) < 0:
        Vt[-1, :] *= -1
        R = Vt.T @ U.T

    if with_scale:
        var = np.var(src_c, axis=0).sum()
        scale = np.sum(S) / var
    else:
        scale = 1.0

    t = mu_dst - scale * (R @ mu_src)

    T = np.eye(4)
    T[:3, :3] = scale * R
    T[:3, 3] = t

    return T


def find_best_geometry_match(detected, reference):
    """
    Find the correspondence between detected reflector centroids
    and surveyed reflector coordinates.

    Every possible correspondence is tested. For each possible
    assignment, a rigid 3-D transformation is calculated and the
    resulting registration RMSE is used to determine the best match.

    This is appropriate for small numbers of reflectors.

    For 6 reflectors:
        6! = 720 possible assignments

    Returns
    -------
    best_T
        Best 4x4 rigid transformation.

    best_perm
        Array giving the ground-truth index corresponding to each
        detected reflector.

    best_residuals
        3-D residual for each detected reflector.

    best_rmse
        Overall registration RMSE.
    """

    detected = np.asarray(detected, dtype=float)
    reference = np.asarray(reference, dtype=float)

    # ---------------------------------------------------------
    # BASIC CHECKS
    # ---------------------------------------------------------

    if len(detected) != len(reference):
        raise ValueError(
            "Detected and reference point counts must match."
        )

    n = len(detected)

    if n < 3:
        raise ValueError(
            "At least 3 reflectors are required."
        )

    print("\nTesting possible reflector correspondences...")
    print(f"Number of reflectors: {n}")

    # Python's math.factorial() is used here.
    import math

    print(
        f"Possible assignments: {math.factorial(n)}"
    )

    # ---------------------------------------------------------
    # SEARCH ALL POSSIBLE ASSIGNMENTS
    # ---------------------------------------------------------

    best_rmse = np.inf
    best_perm = None
    best_T = None
    best_residuals = None

    for perm in permutations(range(n)):

        # Convert tuple to numpy array
        perm = np.array(perm)

        # Rearrange surveyed points according to this
        # possible correspondence.
        candidate_reference = reference[perm]

        # Calculate rigid transformation
        T = compute_umeyama(
            detected,
            candidate_reference,
            with_scale=False
        )

        # Transform detected centroids
        predicted = apply_transform(
            detected,
            T
        )

        # Calculate 3-D residual for every reflector
        residuals = np.linalg.norm(
            predicted - candidate_reference,
            axis=1
        )

        # Overall RMSE
        rmse = np.sqrt(
            np.mean(residuals ** 2)
        )

        # Keep the best assignment
        if rmse < best_rmse:

            best_rmse = rmse
            best_perm = perm.copy()
            best_T = T.copy()
            best_residuals = residuals.copy()

    

    # ---------------------------------------------------------
    # PRINT RESULT
    # ---------------------------------------------------------

    print("\n====================================")
    print("GEOMETRY-BASED REFLECTOR MATCHING")
    print("====================================")

    print(
        f"Best registration RMSE: "
        f"{best_rmse:.4f} m"
    )

    print("\nAssignments:")

    for detected_idx, gt_idx in enumerate(best_perm):

        print(
            f"Detected {detected_idx + 1} "
            f"-> Ground Truth {gt_idx + 1} "
            f"| residual = "
            f"{best_residuals[detected_idx]:.4f} m"
        )

    print("\nResidual summary:")

    for detected_idx, gt_idx in enumerate(best_perm):

        print(
            f"  Detected {detected_idx + 1} "
            f"-> Ground Truth {gt_idx + 1}: "
            f"{best_residuals[detected_idx]:.3f} m"
        )

    print(
        f"\nBest overall RMSE: "
        f"{best_rmse:.3f} m"
    )

    return (
        best_T,
        best_perm,
        best_residuals,
        best_rmse
    )

def umeyama_outlier_rejection(
    detected,
    reference,
    threshold=2.0,
    max_iterations=5
):
    """
    Iterative Umeyama registration with residual-based outlier removal.
    """

    inliers = np.ones(len(detected), dtype=bool)

    for iteration in range(max_iterations):

        # Compute transform using current inliers
        T = compute_umeyama(
            detected[inliers],
            reference[inliers]
        )

        # Apply transform to all detected points
        predicted = apply_transform(
            detected,
            T
        )

        # Calculate residuals
        residuals = np.linalg.norm(
            predicted - reference,
            axis=1
        )

        print(f"\nOutlier rejection iteration {iteration+1}")

        for i, r in enumerate(residuals):
            print(
                f"Reflector {i}: {r:.3f} m"
            )

        # Identify good points
        new_inliers = residuals < threshold


        # Never allow rejection below 3 points
        if np.sum(new_inliers) < 3:

            print(
                "Warning: fewer than 3 inliers found. "
                "Keeping current solution."
            )

            break


        # Stop if stable
        if np.array_equal(new_inliers, inliers):
            break

        inliers = new_inliers


    # Final transform
    T = compute_umeyama(
        detected[inliers],
        reference[inliers]
    )

    predicted = apply_transform(
        detected,
        T
    )

    residuals = np.linalg.norm(
        predicted - reference,
        axis=1
    )

    return T, inliers, residuals




# =========================================================
# PIPELINE
# =========================================================
def estimate_transform(centroids, ref_csv, mode="auto"):

    survey_ids, gt, epsg = load_ground_truth(ref_csv)

    if len(centroids) < 3 or len(gt) < 3:
        raise ValueError(
            "Need at least 3 reflectors for registration"
        )

    if len(centroids) != len(gt):
        raise ValueError(
            f"Detected {len(centroids)} reflectors, "
            f"but found {len(gt)} surveyed reflectors. "
            f"These must currently be equal."
        )

    print("\nDetected centroids:")
    for i, c in enumerate(centroids):
        print(f"{i}: {c}")

    print("\nGround truth coordinates:")

    for i, (survey_id, g) in enumerate(
        zip(survey_ids, gt),
        start=1
    ):
        print(
            f"CSV Row {i} | Survey Reflector ID {survey_id}: {g}"
        )

    # =========================================================
    # FIND REFLECTOR CORRESPONDENCES
    # =========================================================

    print("\nFinding reflector correspondences using geometry...")

    (
        T_match,
        assignment,
        matching_residuals,
        matching_rmse
    ) = find_best_geometry_match(
        centroids,
        gt
    )

    # =========================================================
    # PRINT THE ASSIGNMENTS
    # =========================================================

    print("\n====================================")
    print("FINAL REFLECTOR ASSIGNMENTS")
    print("====================================")

    for detected_idx, gt_idx in enumerate(assignment):

        print(
            f"Detected Cluster {detected_idx + 1} "
            f"-> Survey Reflector ID {survey_ids[gt_idx]} "
            f"(CSV Row {gt_idx + 1})"
        )

    print("\nMatched reflector residuals:")

    for detected_idx, gt_idx in enumerate(assignment):

        print(
            f"Detected Cluster {detected_idx + 1} "
            f"-> Survey Reflector ID {survey_ids[gt_idx]} "
            f"| residual = "
            f"{matching_residuals[detected_idx]:.3f} m"
        )

    print(
        f"\nInitial matching RMSE: "
        f"{matching_rmse:.3f} m"
    )

    # =========================================================
    # HYBRID MODE
    # =========================================================

    if mode == "hybrid":

        print("\nHybrid mode")

        print(
            "The following geometry-based assignments were found:"
        )

        for detected_idx, gt_idx in enumerate(assignment):

            print(
                f"Detected {detected_idx + 1} "
                f"-> Ground Truth {gt_idx + 1}"
            )

        user = input(
            "\nAccept these assignments? [Y/n]: "
        )

        if user.strip().lower() == "n":

            raise ValueError(
                "Automatic assignment rejected. "
                "Run again with match_mode='manual'."
            )

    # =========================================================
    # MANUAL MODE
    # =========================================================

    if mode == "manual":

        print("\nManual matching mode")

        print(
            "Enter the Ground Truth number corresponding "
            "to each detected reflector."
        )

        assignment = []

        used_gt = set()

        for i in range(len(centroids)):

            gt_idx = int(
                input(
                    f"Detected reflector {i + 1} "
                    f"matches Ground Truth: "
                )
            ) - 1

            if gt_idx < 0 or gt_idx >= len(gt):

                raise ValueError(
                    "Invalid Ground Truth number."
                )

            if gt_idx in used_gt:

                raise ValueError(
                    "That Ground Truth point has already "
                    "been assigned."
                )

            used_gt.add(gt_idx)

            assignment.append(gt_idx)

        assignment = np.array(assignment)

    # =========================================================
    # BUILD MATCHED SOURCE / DESTINATION ARRAYS
    # =========================================================

    src = centroids.copy()

    dst = gt[assignment].copy()

    control_detected_indices = np.arange(
        len(centroids)
    )

    # Diagnostic exclusion of selected reflectors.
    # Indices are zero-based: 0 = Reflector 1, 1 = Reflector 2, etc.
    exclude_indices = []

    if mode == "hybrid":

        exclude_text = input(
            "\nExclude any detected reflector numbers for "
            "diagnostic testing? "
            "Enter comma-separated values or press Enter: "
        ).strip()

        if exclude_text:
            exclude_indices = [
                int(value.strip()) - 1
                for value in exclude_text.split(",")
            ]

            keep = np.ones(len(src), dtype=bool)
            keep[exclude_indices] = False

            if np.sum(keep) < 3:
                raise ValueError(
                    "At least three reflectors must remain."
                )

            src = src[keep]
            dst = dst[keep]
            control_detected_indices = (
                control_detected_indices[keep]
            )

            print(
                f"Using {len(src)} reflectors after "
                f"excluding: "
                f"{[index + 1 for index in exclude_indices]}"
            )

    # =========================================================
    # FINAL REGISTRATION + OUTLIER REJECTION
    # =========================================================

    T, inliers, residuals = umeyama_outlier_rejection(
        src,
        dst,
        threshold=0.5
    )

    print("\nFinal reflector selection:")

    for i, keep in enumerate(inliers):

        if keep:

            print(
                f"Reflector {i + 1} ACCEPTED "
                f"({residuals[i]:.3f} m)"
            )

        else:

            print(
                f"Reflector {i + 1} REJECTED "
                f"({residuals[i]:.3f} m)"
            )

    # =========================================================
    # KEEP ONLY ACCEPTED POINTS
    # =========================================================

    src = src[inliers]
    dst = dst[inliers]
    control_detected_indices = (
        control_detected_indices[inliers]
    )

    return (
        T,
        src,
        dst,
        epsg,
        assignment,
        matching_residuals,
        survey_ids,
        gt,
        exclude_indices,
        control_detected_indices
    )
# =========================================================
# OUTPUT
# =========================================================
def save_transform(T, path):
    np.savetxt(path, T)
    print("Saved transform:", path)

def save_correspondence_table(
    centroids,
    assignment,
    survey_ids,
    ground_truth,
    residuals,
    path
):
    """
    Saves detected-cluster to surveyed-reflector correspondence
    information for quality control and field-note comparison.
    """

    rows = []

    for detected_idx, gt_idx in enumerate(assignment):

        rows.append({
            "detected_cluster_rank": detected_idx + 1,
            "survey_reflector_id": survey_ids[gt_idx],
            "survey_csv_row": gt_idx + 1,

            "sensor_enu_x_m": centroids[detected_idx, 0],
            "sensor_enu_y_m": centroids[detected_idx, 1],
            "sensor_enu_z_m": centroids[detected_idx, 2],

            "survey_easting_m": ground_truth[gt_idx, 0],
            "survey_northing_m": ground_truth[gt_idx, 1],
            "survey_height_m": ground_truth[gt_idx, 2],

            "registration_residual_3d_m": residuals[detected_idx]
        })

    df = pd.DataFrame(rows)

    df.to_csv(path, index=False)

    print("Saved correspondence table:", path)


def save_centroids(centroids, path):
    header = laspy.LasHeader(point_format=3, version="1.2")
    las = laspy.LasData(header)

    las.x = centroids[:, 0]
    las.y = centroids[:, 1]
    las.z = centroids[:, 2]

    las.write(path)
    print("Saved centroids:", path)

def save_classified_laz(points, intensity, classification, path):

    header = laspy.LasHeader(point_format=3, version="1.2")
    las = laspy.LasData(header)

    las.x = points[:, 0]
    las.y = points[:, 1]
    las.z = points[:, 2]

    las.intensity = intensity.astype(np.uint16)

    # binary labels
    # 0 = background
    # 1 = reflector
    las.classification = classification.astype(np.uint8)

    las.write(path)

    print("Saved classified point cloud:", path)
    
def apply_transform(points, T):
    """
    Applies 4x4 homogeneous transform to Nx3 points.
    """

    pts_h = np.hstack([
        points,
        np.ones((len(points), 1))
    ])

    transformed = (T @ pts_h.T).T

    return transformed[:, :3]

def save_georegistered_laz(las, transformed_points, path, epsg=None):
    """
    Saves transformed/georegistered point cloud.
    Creates a NEW header with proper offsets/scales.
    """

    header = laspy.LasHeader(
        point_format=las.header.point_format,
        version=las.header.version
    )

    header.scales = np.array([0.001, 0.001, 0.001])
    header.offsets = np.min(transformed_points, axis=0)

    # -------------------------------------------------
    # WRITE CRS / EPSG
    # -------------------------------------------------
    if epsg is not None:
        header.add_crs(CRS.from_epsg(epsg))

    out_las = laspy.LasData(header)

    # -------------------------------------------------
    # COPY ALL EXISTING ATTRIBUTES
    # -------------------------------------------------
    for dim in las.point_format.dimension_names:

        # skip coordinates (we overwrite them)
        if dim.lower() in ["x", "y", "z"]:
            continue

        try:
            setattr(out_las, dim, getattr(las, dim))
        except Exception:
            pass

    # -------------------------------------------------
    # WRITE TRANSFORMED COORDINATES
    # -------------------------------------------------
    out_las.x = transformed_points[:, 0]
    out_las.y = transformed_points[:, 1]
    out_las.z = transformed_points[:, 2]

    out_las.write(path)

    print("Saved georegistered point cloud:", path)

def save_centroid_plot(points, centroids, path):
    """
    Saves a top-down XY plot with numbered reflector centroids.
    """

    plt.figure(figsize=(10, 10))

    # -------------------------------------------------
    # background point cloud (subsampled for speed)
    # -------------------------------------------------
    step = max(1, len(points) // 200000)

    plt.scatter(
        points[::step, 0],
        points[::step, 1],
        s=0.2
    )

    # -------------------------------------------------
    # centroid markers
    # -------------------------------------------------
    plt.scatter(
        centroids[:, 0],
        centroids[:, 1],
        s=120,
        marker="x"
    )

    # -------------------------------------------------
    # labels
    # -------------------------------------------------
    for i, c in enumerate(centroids):

        plt.text(
            c[0],
            c[1],
            str(i),
            fontsize=12
        )

    plt.xlabel("X")
    plt.ylabel("Y")

    plt.title("Detected Reflector Centroids")

    plt.axis("equal")

    plt.savefig(path, dpi=300, bbox_inches="tight")

    plt.close()

    print("Saved centroid plot:", path)

# =========================================================
# ERROR STATISTICS
# =========================================================
def print_centroid_statistics(src, dst, T, plot_path=None):
    """
    Prints centroid registration statistics after applying
    the estimated transform.
    """

    transformed = apply_transform(src, T)
    if plot_path is not None:
        plot_registration_residuals(
            transformed,
            dst,
            plot_path
        )

    residuals = transformed - dst

    dx = residuals[:, 0]
    dy = residuals[:, 1]
    dz = residuals[:, 2]

    horizontal = np.sqrt(dx**2 + dy**2)
    total = np.linalg.norm(residuals, axis=1)

    print("\nTransformed reflector locations")

    for i in range(len(src)):
        print(f"""
    Reflector {i+1}
    Detected:
    {src[i]}

    Predicted UTM:
    {transformed[i]}

    Survey:
    {dst[i]}

    Residual:
    {transformed[i]-dst[i]}
    """)

    print("\n====================================")
    print("CENTROID ERROR STATISTICS")
    print("====================================")

    print("Per-reflector residuals:")
    for i in range(len(src)):
        print(
            f"{i+1:2d}: "
            f"dX={dx[i]:7.3f} m  "
            f"dY={dy[i]:7.3f} m  "
            f"dZ={dz[i]:7.3f} m  "
            f"H={horizontal[i]:7.3f} m  "
            f"3D={total[i]:7.3f} m"
        )

    print("\nSummary")
    print("------------------------------------")

    print(f"Mean X error      : {np.mean(dx):.3f} m")
    print(f"Mean Y error      : {np.mean(dy):.3f} m")
    print(f"Mean Z error      : {np.mean(dz):.3f} m")

    print(f"Std X             : {np.std(dx):.3f} m")
    print(f"Std Y             : {np.std(dy):.3f} m")
    print(f"Std Z             : {np.std(dz):.3f} m")

    print(f"Horizontal RMSE   : {np.sqrt(np.mean(horizontal**2)):.3f} m")
    print(f"Vertical RMSE     : {np.sqrt(np.mean(dz**2)):.3f} m")
    print(f"3D RMSE           : {np.sqrt(np.mean(total**2)):.3f} m")

    print(f"Mean Horizontal   : {np.mean(horizontal):.3f} m")
    print(f"Mean 3D Error     : {np.mean(total):.3f} m")

    print(f"Maximum Error     : {np.max(total):.3f} m")
    print(f"Minimum Error     : {np.min(total):.3f} m")

def plot_registration_residuals(transformed, ground_truth, save_path):
    """
    Plot transformed reflector centroids against survey coordinates
    with residual vectors.
    """

    import matplotlib.pyplot as plt

    plt.figure(figsize=(8,8))

    # Survey locations
    plt.scatter(
        ground_truth[:,0],
        ground_truth[:,1],
        s=120,
        marker='o',
        label='Survey'
    )

    # Registered centroids
    plt.scatter(
        transformed[:,0],
        transformed[:,1],
        s=120,
        marker='x',
        label='Detected'
    )

    # Residual vectors
    for i in range(len(ground_truth)):

        plt.plot(
            [ground_truth[i,0], transformed[i,0]],
            [ground_truth[i,1], transformed[i,1]],
            'r-',
            linewidth=2
        )

        plt.text(
            ground_truth[i,0],
            ground_truth[i,1],
            f"G{i}",
            fontsize=10
        )

        plt.text(
            transformed[i,0],
            transformed[i,1],
            f"D{i}",
            fontsize=10
        )

    plt.xlabel("Easting (m)")
    plt.ylabel("Northing (m)")
    plt.title("Reflector Registration Residuals")

    plt.axis("equal")
    plt.grid(True)
    plt.legend()

    plt.savefig(save_path, dpi=300, bbox_inches="tight")
    plt.close()

    print("Saved residual plot:", save_path)

def save_registration_error_report(
    src,
    dst,
    T,
    survey_labels,
    detected_indices,
    csv_path,
    plot_path,
    role="control"
):
    """
    Saves a CSV error report and a horizontal residual plot.

    Parameters
    ----------
    src
        Detected reflector centroids in sensor-local orientation frame.

    dst
        Matching surveyed reflector coordinates.

    T
        Final rigid-body transformation.

    survey_labels
        Survey reflector IDs, such as ref-2, ref-5, etc.

    detected_indices
        Original detected-cluster indices.

    csv_path
        Output CSV path.

    plot_path
        Output PNG path.

    role
        Label applied to rows, such as 'control' or 'check_point'.
    """

    transformed = apply_transform(
        src,
        T
    )

    residuals = transformed - dst

    dx = residuals[:, 0]
    dy = residuals[:, 1]
    dz = residuals[:, 2]

    horizontal_error = np.sqrt(
        dx**2 + dy**2
    )

    error_3d = np.linalg.norm(
        residuals,
        axis=1
    )

    rows = []

    for i in range(len(src)):

        rows.append({
            "role": role,
            "detected_cluster": int(
                detected_indices[i] + 1
            ),
            "survey_reflector_id": survey_labels[i],

            "predicted_easting_m": transformed[i, 0],
            "predicted_northing_m": transformed[i, 1],
            "predicted_height_m": transformed[i, 2],

            "survey_easting_m": dst[i, 0],
            "survey_northing_m": dst[i, 1],
            "survey_height_m": dst[i, 2],

            "dE_m": dx[i],
            "dN_m": dy[i],
            "dZ_m": dz[i],

            "horizontal_error_m": horizontal_error[i],
            "error_3d_m": error_3d[i]
        })

    df = pd.DataFrame(rows)

    df.to_csv(
        csv_path,
        index=False
    )

    # -------------------------------------------------
    # CREATE RESIDUAL PLOT
    # Use a local coordinate origin so UTM values are
    # easier to read.
    # -------------------------------------------------

    origin = dst[0, :2]

    survey_xy = dst[:, :2] - origin
    predicted_xy = transformed[:, :2] - origin

        # Pivox scanner origin in transformed coordinates.
    # This represents the lidar sensor origin, not
    # necessarily the physical center of the full Pivox enclosure.
    scanner_utm = apply_transform(
        np.array([[0.0, 0.0, 0.0]]),
        T
    )[0]

    scanner_xy = scanner_utm[:2] - origin

    plt.figure(figsize=(9, 8))

    plt.scatter(
        survey_xy[:, 0],
        survey_xy[:, 1],
        s=100,
        marker="o",
        color="tab:blue",
        label="Surveyed reflector"
    )

    plt.scatter(
        predicted_xy[:, 0],
        predicted_xy[:, 1],
        s=100,
        marker="x",
        color="tab:orange",
        label="Registered Pivox centroid"
    )

    plt.scatter(
        scanner_xy[0],
        scanner_xy[1],
        s=220,
        marker="*",
        color="black",
        edgecolor="white",
        linewidth=0.8,
        label="Pivox scanner origin",
        zorder=5
    )

    plt.text(
        scanner_xy[0],
        scanner_xy[1],
        "Pivox\nscanner",
        fontsize=9,
        ha="left",
        va="bottom",
        color="black"
    )

    # -------------------------------------------------
    # Scanner-to-reflector horizontal ranges
    # -------------------------------------------------

    scanner_ranges_m = np.linalg.norm(
        dst[:, :2] - scanner_utm[:2],
        axis=1
    )

    for i in range(len(dst)):

        # Draw scanner-to-surveyed-reflector range line.
        plt.plot(
            [
                scanner_xy[0],
                survey_xy[i, 0]
            ],
            [
                scanner_xy[1],
                survey_xy[i, 1]
            ],
            linestyle="--",
            color="gray",
            linewidth=0.8,
            alpha=0.6,
            zorder=1
        )

        # Place range label halfway along the line.
        midpoint_x = (
            scanner_xy[0] + survey_xy[i, 0]
        ) / 2

        midpoint_y = (
            scanner_xy[1] + survey_xy[i, 1]
        ) / 2

        plt.text(
            midpoint_x,
            midpoint_y,
            f"{scanner_ranges_m[i]:.1f} m",
            fontsize=8,
            color="dimgray",
            ha="center",
            va="center",
            bbox={
                "facecolor": "white",
                "edgecolor": "none",
                "alpha": 0.7,
                "pad": 1
            }
        )

    for i in range(len(src)):

        plt.plot(
            [
                survey_xy[i, 0],
                predicted_xy[i, 0]
            ],
            [
                survey_xy[i, 1],
                predicted_xy[i, 1]
            ],
            color="red",
            linewidth=1.5
        )

        plt.text(
            survey_xy[i, 0],
            survey_xy[i, 1],
            (
                f"{survey_labels[i]}\n"
                f"D{detected_indices[i] + 1}\n"
                f"{error_3d[i]:.3f} m"
            ),
            fontsize=9,
            ha="left",
            va="bottom"
        )

    rmse_3d = np.sqrt(
        np.mean(error_3d**2)
    )

    plt.title(
        f"Reflector Registration Residuals\n"
        f"{role.capitalize()} 3D RMSE: "
        f"{rmse_3d:.3f} m"
    )

    plt.xlabel(
        f"Easting relative to "
        f"{origin[0]:.3f} m"
    )

    plt.ylabel(
        f"Northing relative to "
        f"{origin[1]:.3f} m"
    )

    plt.axis("equal")
    plt.grid(True, alpha=0.3)
    plt.legend()

    plt.savefig(
        plot_path,
        dpi=300,
        bbox_inches="tight"
    )

    plt.close()

    print(
        "Saved registration error CSV:",
        csv_path
    )

    print(
        "Saved registration residual plot:",
        plot_path
    )

def sensor_to_local_orientation(points):
    """
    Applies the current Pivox sensor-axis sign convention.

    Current orientation:
        X -> X
        Y -> -Y
        Z -> -Z

    This is a local sensor-frame orientation adjustment.
    It does not independently establish Earth-referenced ENU.
    """

    enu = points.copy()

    enu[:, 1] *= -1
    enu[:, 2] *= -1

    return enu

# =========================================================
# MAIN
# =========================================================
def main():
        
        parser = argparse.ArgumentParser(
            description="Reflector-based georegistration"
        )

        parser.add_argument(
            "config",
            help="Path to JSON config file"
        )

        args = parser.parse_args()

        # -------------------------------------------------
        # LOAD JSON CONFIG
        # -------------------------------------------------
        with open(args.config, "r") as f:
            cfg = json.load(f)

        laz_file = cfg["laz_file"]
        num_targets = cfg["num_targets"]
        ref_csv = cfg["ref_csv"]

        match_mode = cfg.get("match_mode", "auto")

        verbose = cfg.get("verbose", False)

        if verbose:

            print("\nCentroids:")

            for i, c in enumerate(centroids):
                print(i + 1, c)

        print_candidate_diagnostics = cfg.get(
            "print_candidate_diagnostics",
            False
        )

        # -------------------------------------------------
        # VALIDATE
        # -------------------------------------------------
        if match_mode not in ["auto", "manual", "hybrid"]:
            raise ValueError(
                f"Invalid match_mode: {match_mode}"
            )

        path = Path(laz_file)

        print("====================================")
        print("CONFIG")
        print("====================================")
        print("LAZ File:", laz_file)
        print("Targets:", num_targets)
        print("Reference CSV:", ref_csv)
        print("Match Mode:", match_mode)
        print("====================================\n")

        # -------------------------------------------------
        # LOAD POINT CLOUD
        # -------------------------------------------------
        print("Loading:", path)

        las, points, intensity = load_laz(path)

        # -------------------------------------------------
        # Convert entire point cloud from sensor frame to ENU
        # -------------------------------------------------

        enu_points = sensor_to_local_orientation(points)

        # Copy for plotting
        #plot_points = enu_points.copy()

        # -------------------------------------------------
        # DETECT REFLECTORS
        # -------------------------------------------------
        print("Detecting reflectors...")

        centroids, mask, _, classification = detect_reflectors(
            points,
            intensity,
            num_targets,
            print_candidate_diagnostics=print_candidate_diagnostics
        )

        # -------------------------------------------------
        # Convert reflector centroids from sensor frame to ENU
        # -------------------------------------------------

        centroids = sensor_to_local_orientation(centroids)

        print("\nCentroids:")

        for i, c in enumerate(centroids):
            print(i + 1, c)

        # -------------------------------------------------
        # ESTIMATE TRANSFORM
        # -------------------------------------------------
        print("\nEstimating transform...")

        (
            T,
            src,
            dst,
            epsg,
            assignment,
            matching_residuals,
            survey_ids,
            gt,
            excluded_detected_indices,
            control_detected_indices
        ) = estimate_transform(
            centroids,
            ref_csv,
            mode=match_mode
        )

        control_survey_labels = [
            survey_ids[
                assignment[detected_idx]
            ]
            for detected_idx in control_detected_indices
        ]

        print("\nTransformation matrix:\n")
        print(T)

        print_centroid_statistics(
        src,
        dst,
        T,
        path.with_name(path.stem + "_registration_residuals.png")
        )

        save_registration_error_report(
            src,
            dst,
            T,
            control_survey_labels,
            control_detected_indices,
            path.with_name(
                path.stem + "_control_error_report.csv"
            ),
            path.with_name(
                path.stem + "_control_residuals.png"
            ),
            role="control"
        )

        save_reflector_configuration_table(
            survey_ids,
            gt,
            T,
            path.with_name(
                path.stem + "_reflector_configuration.csv"
            )
        )

        # -------------------------------------------------
        # VALIDATION
        # -------------------------------------------------

        if len(src) >= 4:

            leave_one_out_validation(
                src,
                dst
            )

        elif len(src) == 3:

            print("\n====================================")
            print("THREE-CONTROL VALIDATION")
            print("====================================")

            print(
                "Leave-one-out validation skipped: "
                "withholding one of three controls leaves "
                "only two reflectors."
            )

            print(
                "Use excluded reflectors as independent "
                "check points for this configuration."
            )

        else:

            raise ValueError(
                "Fewer than three reflectors remain."
            )

        # -------------------------------------------------
        # APPLY TRANSFORM
        # -------------------------------------------------

        print("\nApplying ENU -> UTM transform to full point cloud...")

        transformed_points = apply_transform(
            enu_points,
            T
        )


        # -------------------------------------------------
        # OUTPUTS
        # -------------------------------------------------
        save_transform(
            T,
            path.with_suffix(".transform.txt")
        )

        save_centroids(
            centroids,
            path.with_name(path.stem + "_centroids.laz")
        )

        fig, ax = plt.subplots(
            1,
            3,
            figsize=(18, 6)
        )

        step = max(
            1,
            len(enu_points) // 200000
        )

        ax[0].scatter(
            enu_points[::step, 0],
            enu_points[::step, 1],
            s=0.2
        )

        ax[1].scatter(
            enu_points[::step, 0],
            enu_points[::step, 2],
            s=0.2
        )

        ax[2].scatter(
            enu_points[::step, 1],
            enu_points[::step, 2],
            s=0.2
        )

        ax[0].set_title("XY View")
        ax[1].set_title("XZ View")
        ax[2].set_title("YZ View")

        ax[0].set_xlabel("X")
        ax[0].set_ylabel("Y")

        ax[1].set_xlabel("X")
        ax[1].set_ylabel("Z")

        ax[2].set_xlabel("Y")
        ax[2].set_ylabel("Z")

        for axis in ax:
            axis.set_aspect("equal")

        fig.savefig(
            path.with_name(
                path.stem + "_diagnostic_views.png"
            ),
            dpi=300,
            bbox_inches="tight"
        )

        plt.close(fig)

        save_classified_laz(
        enu_points,
        intensity,
        classification,
        path.with_name(path.stem + "_classified_enu.laz")
        )

        save_correspondence_table(
        centroids,
        assignment,
        survey_ids,
        gt,
        matching_residuals,
        path.with_name(path.stem + "_reflector_correspondence.csv")
        )

        save_georegistered_laz(
            las,
            transformed_points,
            path.with_name(path.stem + "_georegistered.laz"),
            epsg
        )

        print("\nDone.")


if __name__ == "__main__":
    main()
    